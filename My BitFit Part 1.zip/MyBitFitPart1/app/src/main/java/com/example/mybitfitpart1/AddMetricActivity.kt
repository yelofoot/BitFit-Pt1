package com.example.mybitfitpart1

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class AddMetricActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_metric)

        val metricNameEditText = findViewById<EditText>(R.id.metricNameEditText)
        val metricValueEditText = findViewById<EditText>(R.id.metricValueEditText)
        val saveButton = findViewById<Button>(R.id.saveButton)

        saveButton.setOnClickListener {
            val metricName = metricNameEditText.text.toString()
            val metricValue = metricValueEditText.text.toString()

            if (metricName.isNotEmpty() && metricValue.isNotEmpty()) {
                val resultIntent = Intent()
                resultIntent.putExtra("METRIC_NAME", metricName)
                resultIntent.putExtra("METRIC_VALUE", metricValue)
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            }
        }
    }
}

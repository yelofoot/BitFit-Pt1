package com.example.mybitfitpart1

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase
    private lateinit var healthMetricDao: HealthMetricDao
    private val adapter = HealthMetricAdapter(::deleteMetric)
    private lateinit var summaryTextView: TextView

    private val addMetricResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.let {
                val metricName = it.getStringExtra("METRIC_NAME")
                val metricValue = it.getStringExtra("METRIC_VALUE")

                if (metricName != null && metricValue != null) {
                    lifecycleScope.launch {
                        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                        val currentDate = sdf.format(Date())
                        healthMetricDao.insert(HealthMetric(date = currentDate, metricName = metricName, metricValue = metricValue))
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        summaryTextView = findViewById(R.id.summaryTextView)

        // Database setup
        db = AppDatabase.getInstance(applicationContext)
        healthMetricDao = db.healthMetricDao()

        // RecyclerView setup
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Observe data
        lifecycleScope.launch {
            healthMetricDao.getAll().collect { metrics ->
                adapter.submitList(metrics)
            }
        }

        // Observe average
        lifecycleScope.launch {
            healthMetricDao.getAverage("Sleep").collect { average ->
                val df = DecimalFormat("#.##")
                val formattedAverage = if (average != null) df.format(average) else "N/A"
                summaryTextView.text = "Average Sleep: $formattedAverage hours"
            }
        }

        // Add metric button setup
        val addMetricButton: ExtendedFloatingActionButton = findViewById(R.id.addMetricButton)
        addMetricButton.setOnClickListener {
            val intent = Intent(this, AddMetricActivity::class.java)
            addMetricResultLauncher.launch(intent)
        }
    }

    private fun deleteMetric(metric: HealthMetric) {
        lifecycleScope.launch {
            healthMetricDao.delete(metric)
        }
    }
}